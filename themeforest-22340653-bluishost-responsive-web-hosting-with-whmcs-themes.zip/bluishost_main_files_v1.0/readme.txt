Bluishost is a Multipurpose Hosting with WHMCS and Technology Business WordPress Theme designed for All kinds of Technology, VOIP, Cloud Service, Telecom, Domain and Hosting Business. Also included a custom WHMCS template based on WHMCS v7.5.1 to use separately. Bluishost is a theme for technology and software businesses as well as for VOIP and web hosting companies based on Visual Composer. The theme has all the required functionality for a hosting services company, including domain search and registration functionality with WHMCS. Fancy pricing tables let you display hosting prices for different server configurations and hosting packages. If you need to create a website for a hosting company, a technology blog or a software review blog, Hosting Business Technology WP Theme is a great choice.


==========================================================================================================
WHMCS Template included in "whmcs-template" (folder) with installation instruction "readme.txt"
==========================================================================================================

==========================================================================
Well Sorted Documentation included in "documentation" (folder).
==========================================================================

=========================================================
Changelog included in "documentation/changelog" (folder).
=========================================================


SOURCE AND CREADITS:
====================

Photos:

    All 'images' used on the demo site is for demonstration purposes only and are not included in the main download file.

Fonts Used:

    Google Fonts (Raleway) - http://www.google.com/webfonts
    Font Awesome - http://fontawesome.io/

Frameworks / Libraries:

    reduxframework - https://reduxframework.com/
    CMB2 - https://wordpress.org/plugins/cmb2/

    jQuery - https://jquery.com/
    Twitter Bootstrap - http://getbootstrap.com

Plugins Used:

    Visual Composer - https://vc.wpbakery.com/
    Contact Form 7 - https://wordpress.org/plugins/contact-form-7/

    Waypoints - https://github.com/imakewebthings/waypoints/
    jQuery CounterUP - https://github.com/bfintal/Counter-Up
    jquery ajaxchimp - https://github.com/scdoshi/jquery-ajaxchimp